import { StudentService } from './../student.service';
import { Student } from './../student';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register-student',
  templateUrl: './register-student.component.html',
  styleUrls: ['./register-student.component.css']
})
export class RegisterStudentComponent implements OnInit {
  student: Student=new Student();
  constructor(private studentservice: StudentService,
    private router:Router) { }

  ngOnInit(): void 
  {
    
  }
  saveStudent(){
    this.studentservice.registerStudent(this.student).subscribe(data=>{
      console.log(data);
      
    
    },
    error=>console.log(error));
  }

  goToStudentList(){
    this.router.navigate(['/students']);

  }

  onSubmit(){
    console.log(this.student);
    this.saveStudent();
    this.goToStudentList();
    
  }
}
